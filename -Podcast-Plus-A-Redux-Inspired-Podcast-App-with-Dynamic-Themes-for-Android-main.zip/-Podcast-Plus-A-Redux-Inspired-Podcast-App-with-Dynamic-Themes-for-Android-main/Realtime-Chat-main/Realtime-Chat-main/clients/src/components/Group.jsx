version https://git-lfs.github.com/spec/v1
oid sha256:87d8b52095cbe2b31db6fc26bad3def14fbbbae1b9501e3fd4462b7de7cf9a89
size 4050
