version https://git-lfs.github.com/spec/v1
oid sha256:f7784693194b8657d1bf70c37ea70f4a2d694c4566ec41550a8e650eb600aaa4
size 246
