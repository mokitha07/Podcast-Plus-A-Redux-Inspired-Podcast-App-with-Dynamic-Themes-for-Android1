version https://git-lfs.github.com/spec/v1
oid sha256:424ad1b1def8a5befa0acacc6ea3dde0402bbd9722ad6cd5d4605ccfd1226a24
size 317
