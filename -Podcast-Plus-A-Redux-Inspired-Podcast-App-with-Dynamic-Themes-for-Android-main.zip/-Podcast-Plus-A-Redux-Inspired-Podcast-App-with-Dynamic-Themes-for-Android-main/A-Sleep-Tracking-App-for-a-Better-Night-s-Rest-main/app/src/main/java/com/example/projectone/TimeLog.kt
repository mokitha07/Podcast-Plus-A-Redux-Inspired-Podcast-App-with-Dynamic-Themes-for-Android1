version https://git-lfs.github.com/spec/v1
oid sha256:f0ba506bea172d6d16f1834fe95f3d66b10a926090fc7a466915524c4e8387d2
size 288
